/// <reference path='./vendor/babylon.d.ts' />

console.log('hello world!!!');
